export const users = [
    {
    id: "1",
    name: "Joaquin",
    email: 'jpappa2603@gmail.com',
    password: 'Jejb2603',
    rol: "admin"
    },
    {
    id: "2",
    name: "Shirley",
    email: 'shirley@gmail.com',
    password: 'Jejb2603',
    rol: "citizen"
    }, 
    {
    id: "3",
    name: "Josue",
    email: 'josue@gmail.com',
    password: 'Jejb2603',
    rol: "entrepreneur"
    }, 
]
